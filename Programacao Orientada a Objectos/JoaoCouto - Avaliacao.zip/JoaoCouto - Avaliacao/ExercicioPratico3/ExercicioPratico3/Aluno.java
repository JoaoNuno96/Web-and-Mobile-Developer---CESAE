public class Aluno
{
    public String nome;
    public float nota;
    
    public Aluno(String nameUser, float notaUser)
    {
        this.nome = nameUser;
        this.nota = notaUser;
    }
}